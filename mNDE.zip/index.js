import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import { SerialPort } from "serialport";
import { ReadlineParser } from "@serialport/parser-readline";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.static(path.join(__dirname, "main")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "main", "html", "index.html"));
});

// Arduino Serial
const portName = "COM3"; // ggf. anpassen
const serialPort = new SerialPort({
  path: portName,
  baudRate: 9600,
});

const parser = serialPort.pipe(new ReadlineParser({ delimiter: "\n" }));

let letzterWert = {
  temp: null,
  hum: null,
  heatIndex: null,
  taupunkt: null,
};

parser.on("data", (data) => {
  try {
    const messdaten = JSON.parse(data);
    letzterWert = messdaten;
    console.log("Empfangen:", messdaten);
  } catch (e) {
    console.error("Fehler beim Parsen:", data);
  }
});

serialPort.on("error", (err) => {
  console.error("SerialPort-Fehler:", err.message);
});

app.get("/daten", (req, res) => {
  res.json(letzterWert);
});

app.get("/berichteAktuelles", (req, res) => {
  const data = fs.readFileSync("./main/json/berichte-aktuelles.json", {
    encoding: "utf8",
    flag: "r",
  });
  console.log("Aktuelles:" + data);
  res.send(data);
});

app.get("/datenLocal", (req, res) => {
  res.json({
    lat: 50.1833,
    lon: 8.5,
    temp: letzterWert.temp,
    hum: letzterWert.hum,
  });
});

//Keine DWD Such-Route aufgrund der Latenz --> Siehe dwd-client.js 


app.listen(port, () => {
  console.log(`Server läuft unter http://localhost:${port}`);
});
