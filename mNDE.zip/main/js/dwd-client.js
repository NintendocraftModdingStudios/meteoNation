// dwd-client.js

export let dwdGeoJsonData = null;

/**
 * Holt DWD-Daten direkt von der DWD-WFS-API
 */
export async function ladeDWD() {
  try {
    const url = 'https://maps.dwd.de/geoserver/dwd/ows?service=WFS&version=1.1.0&request=GetFeature&typeName=dwd:RBSN_T2m&outputFormat=application/json';

    const res = await fetch(url);
    if (!res.ok) throw new Error(`Fehler beim Laden der DWD-Daten: ${res.status}`);

    const data = await res.json();
    dwdGeoJsonData = data;
    console.log("DWD-Daten geladen", data);
    return data;
  } catch (err) {
    console.error("DWD-Daten konnten nicht geladen werden:", err);
    return null;
  }
}

/**
 * Findet die nächste Station aus den geladenen DWD-Daten zu einem Leaflet LatLng-Objekt
 * @param {L.LatLng} latlng 
 * @returns {object|null} Feature der nächsten Station oder null
 */
export function findeNaechsteStation(latlng) {
  if (!dwdGeoJsonData || !dwdGeoJsonData.features) return null;

  let minDist = Infinity;
  let naechsteStation = null;

  dwdGeoJsonData.features.forEach(feature => {
    const [lon, lat] = feature.geometry.coordinates;
    const stationLatLng = L.latLng(lat, lon);
    const dist = latlng.distanceTo ? latlng.distanceTo(stationLatLng) : 0;

    if (dist < minDist) {
      minDist = dist;
      naechsteStation = feature;
    }
  });

  return naechsteStation;
}
