
const weatherMap = L.map('weatherMap', {
    maxBounds: L.latLngBounds([47.0, 5.5], [55.1, 15.1]),
    maxBoundsViscosity: 1.0,
    minZoom: 5.5,
    maxZoom: 18,
}).setView([51.1657, 10.4515], 6);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© OpenStreetMap',
    maxZoom: 18,
    minZoom: 2,
}).addTo(weatherMap);

// DWD WMS-Layer
const niederschlagLayer = L.tileLayer.wms("https://maps.dwd.de/geoserver/dwd/wms", {
    layers: "dwd:_Niederschlagsradar",
    format: "image/png",
    transparent: true,
    attribution: "DWD ©",
    opacity: 0.6
});
const temperaturLayer = L.tileLayer.wms("https://maps.dwd.de/geoserver/dwd/wms", {
    layers: "dwd:TAMM_17_1961_30",
    format: "image/png",
    transparent: true,
    attribution: "DWD ©",
    opacity: 0.6
});

niederschlagLayer.addTo(weatherMap);
L.control.layers({
    "Niederschlag": niederschlagLayer,
    "Temperatur (Durchschnitt)": temperaturLayer
}).addTo(weatherMap);

export default weatherMap;
